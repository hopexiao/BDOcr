/*==============================================================================
Copyright (c) 2010-2013 QUALCOMM Austria Research Center GmbH.
All Rights Reserved.
Qualcomm Confidential and Proprietary
==============================================================================*/


#import <UIKit/UIKit.h>


// OverlayView is used to display UI objects over another view
@interface OverlayView : UIView {
    // No data members required
}

@end
