/*==============================================================================
 Copyright (c) 2012-2013 QUALCOMM Austria Research Center GmbH.
 All Rights Reserved.
 Qualcomm Confidential and Proprietary
 ==============================================================================*/

#import "UDTOverlayViewController.h"
#import "QCARutils.h"

@implementation UDTOverlayViewController

- (void) populateActionSheet
{
    flashIx = MENU_OPTION_WANTED;
    [super populateActionSheet];
}

@end
